# 梼杌
基于cobalt strike平台的红队自动化框架

![Alt text](https://github.com/pandasec888/taowu-cobalt-strike/blob/master/img/timg.jpg)

# 仅供交流与学习使用，严禁用于非法用途！

taowu的script目录下所有文件均为网上搜集，不保证安全问题，请务必自主进行相关安全审查！
# [English-version](https://github.com/pandasec888/taowu-cobalt-strike/tree/english)
感谢[vcarus](https://twitter.com/h4ltorg)提供英文翻译支持

Thanks to [vcarus](https://twitter.com/h4ltorg) for English translation support
# 功能简介
![](img/xx.png)
![](img/pz.png)
![](img/xt.png)
![](img/gy.png)
# 贡献者
[vcarus](https://twitter.com/h4ltorg)

[NULLB8](https://github.com/NULLB8)
# Tips
1.梼杌本身是一个原创加学习结合的项目，一开始就具备了包容的属性，感谢github具有分享精神的大佬开源了这么多优秀的代码，站在巨人的肩膀上总是能看见更大的世界。

2.为了更好的维护该项目，现邀请对此项目感兴趣的所有人共同参与维护开发，项目维护开发不限功能不限技术水平，即使只是输出一个whoami。参与维护的大佬可以直接将代码提交至github或者发送到邮箱taowuopen@protonmail.com或者加入知识星球进行交流。

3.参与维护开发的大佬请在邮件中注明自己的ID与github或是博客地址，以上内容将永久附在github项目页面以及梼杌关于模块一栏。

# 知识星球
分享与交流一线红队知识与技术。星主参与近三十场攻防演练，均为红队。希望借助知识星球社群认识更多的人以及学习更多的知识与技术，与同样热衷网络安全红队技术的人共同进步，提高自身技术水平的同时为网络安全行业贡献绵薄之力。
### 加入方式
为了保证星球质量，星球设置两种加入方式

1.小额付费方式（星球创建第1个月88，第2个月开始调至188，介意勿加）

2.投稿红队相关原创技术文章、原创漏洞、原创工具三类中任意一类至邮箱：taowuopen@protonmail.com，经审核通过免付费邀请加入。

作为回馈，星球内为成员提供梼杌(taowu-cobalt strike)完整版本(梼杌完整版将在知识星球内不定期更新)
![](img/xingqiu.jpg)
# 参考
https://github.com/DeEpinGh0st/Erebus

https://github.com/timwhitez/Cobalt-Strike-Aggressor-Scripts

https://github.com/0x09AL/RdpThief

https://github.com/uknowsec/sharptoolsaggressor

https://github.com/lengjibo/RedTeamTools/tree/master/windows/Cobalt%20Strike

https://github.com/k8gege/Ladon

如有遗漏，请见谅。
